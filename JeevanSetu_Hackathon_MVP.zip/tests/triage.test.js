import { assessRisk, resetSession } from '../server/services/triage.js';
import { parseVitals } from '../server/services/vitals.js';
import { extractAge, isNegated, isDenied, canonicalize } from '../server/lib/text.js';

const level = (text, options) => assessRisk(text, options).level;
const ids = (text, options) => assessRisk(text, options).flagsDetail.map(f => f.id);

describe('red-flag detection across languages', () => {
  test.each([
    ['chest pain and sweating', 'en'],
    ['सीने में दर्द है', 'hi'],
    ['seene me dard hai', 'hinglish'],
    ['chest mein bahut dard hai', 'hinglish']
  ])('chest pain is emergency: %s', (text) => {
    expect(level(text)).toBe('emergency');
  });

  test.each([
    ['difficulty breathing', 'breathing_difficulty'],
    ['saans lene mein problem ho rahi hai', 'breathing_difficulty_free_order'],
    ['saans nahi le pa raha hun', 'breathing_difficulty_free_order']
  ])('breathing difficulty is emergency: %s', (text, expected) => {
    expect(ids(text)).toContain(expected);
    expect(level(text)).toBe('emergency');
  });

  test('word order does not matter for combination rules', () => {
    expect(level('pregnant hoon aur khoon aa raha hai')).toBe('emergency');
    expect(level('khoon aa raha hai, pregnant hoon')).toBe('emergency');
  });

  test('self harm is a crisis emergency in Hinglish', () => {
    expect(level('main apne aap ko nuksan pahunchana chahta hoon')).toBe('emergency');
  });

  test('plain fever without severity stays routine', () => {
    expect(level('2 din se bukhar hai')).toBe('routine');
  });
});

describe('negation', () => {
  test('post-posed Hindi negation suppresses the flag', () => {
    const result = assessRisk('seene me dard nahi hai');
    expect(result.level).toBe('routine');
    expect(result.negatedFlags.map(f => f.id)).toContain('chest_pain');
  });

  test('English pre-posed negation suppresses the flag', () => {
    expect(level('no chest pain, just cough')).toBe('routine');
  });

  test('negation of cessation still escalates', () => {
    expect(level('seene me dard nahi ruk raha')).toBe('emergency');
  });

  test('negation in another clause does not suppress a real flag', () => {
    expect(level('bukhar nahi hai par seene me dard hai')).toBe('emergency');
  });

  test('isDenied only treats adjacent negation as a denial', () => {
    const text = canonicalize('bukhar nahi hai par seene me dard hai');
    expect(isDenied(text, 'seene')).toBe(false);
    expect(isDenied(canonicalize('seene me dard nahi hai'), 'dard')).toBe(true);
    expect(isNegated(canonicalize('no chest pain'), 'chest pain')).toBe(true);
  });
});

describe('vitals parsing', () => {
  test('blood pressure', () => {
    expect(parseVitals('bp 150/95').bloodPressure).toMatchObject({ systolic: 150, diastolic: 95 });
  });

  test('temperature unit inference and Hinglish number-first order', () => {
    const vitals = parseVitals('mere bete ko 103 bukhar hai');
    expect(vitals.temperature).toMatchObject({ fahrenheit: 103, reportedUnit: 'F' });
    expect(parseVitals('temp 39.4').temperature.celsius).toBe(39.4);
  });

  test('spo2 and glucose', () => {
    const vitals = parseVitals('spo2 88% sugar 320');
    expect(vitals.spo2).toBe(88);
    expect(vitals.glucose).toBe(320);
  });

  test('implausible readings are rejected', () => {
    expect(parseVitals('bp 300/200').bloodPressure).toBeNull();
  });

  test('critical vitals raise urgency', () => {
    expect(level('spo2 84')).toBe('emergency');
    expect(level('bp 185/120')).toBe('emergency');
  });
});

describe('age extraction', () => {
  test('Hindi oblique case is recognised', () => {
    expect(extractAge('mere 5 saal ke bete ko bukhar hai')).toMatchObject({ value: 5, unit: 'years' });
  });

  test('a duration is not mistaken for an age', () => {
    expect(extractAge('2 din se bukhar hai')).toBeNull();
    expect(extractAge('I have had a cold for 2 days')).toBeNull();
  });

  test('infant fever escalates', () => {
    expect(level('mere 2 mahine ke bachche ko 101 bukhar hai')).toBe('emergency');
  });
});

describe('session memory only escalates', () => {
  const sessionId = 'test-session-escalate';

  beforeEach(() => resetSession(sessionId));

  test('a later reassuring message cannot lower the level', () => {
    expect(assessRisk('chest pain', { sessionId }).level).toBe('emergency');
    const after = assessRisk('ab theek lag raha hai', { sessionId });
    expect(after.level).toBe('emergency');
  });

  test('a fresh session starts clean', () => {
    assessRisk('chest pain', { sessionId });
    resetSession(sessionId);
    expect(assessRisk('sirf halki khasi hai', { sessionId }).level).not.toBe('emergency');
  });
});
