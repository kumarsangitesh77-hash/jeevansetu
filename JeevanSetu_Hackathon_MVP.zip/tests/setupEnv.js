import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// Runs before each test file's imports, so config.js picks these up when it
// builds its paths. Tests must never touch the real server/state directory.
const dir = path.join(os.tmpdir(), `jeevansetu-test-${process.pid}`);
fs.rmSync(dir, { recursive: true, force: true });

process.env.NODE_ENV = 'test';
process.env.DATA_DIR = dir;
process.env.LOG_LEVEL = 'silent';
process.env.LLM_ENABLED = 'false';

process.on('exit', () => {
  fs.rmSync(dir, { recursive: true, force: true });
});
