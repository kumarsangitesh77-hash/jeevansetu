import { grantConsent, redeemShare, revokeConsent, validateFields, resetConsents } from '../server/services/consent.js';
import { HttpError } from '../server/lib/errors.js';

const payload = {
  symptoms: ['Chest pain or pressure'],
  riskLevel: 'emergency',
  vitals: { bloodPressure: { systolic: 150, diastolic: 95 } },
  transcript: [{ role: 'user', text: 'my secret words' }]
};

describe('field validation', () => {
  test('empty selection is rejected', () => {
    expect(() => validateFields([])).toThrow(HttpError);
  });

  test('unknown fields are rejected', () => {
    expect(() => validateFields(['symptoms', 'bankPassword'])).toThrow(/Unsupported field/);
  });

  test('duplicates collapse', () => {
    expect(validateFields(['symptoms', 'symptoms'])).toEqual(['symptoms']);
  });
});

describe('consent-scoped snapshots', () => {
  beforeEach(() => resetConsents());

  test('only ticked fields are copied into the snapshot', () => {
    const consent = grantConsent({ selectedFields: ['symptoms', 'riskLevel'], payload });
    const view = redeemShare(consent.token);
    expect(view.snapshot).toEqual({ symptoms: payload.symptoms, riskLevel: 'emergency' });
    expect(view.snapshot.transcript).toBeUndefined();
    expect(view.snapshot.vitals).toBeUndefined();
  });

  test('unticked sensitive fields never reach the recipient', () => {
    const consent = grantConsent({ selectedFields: ['riskLevel'], payload });
    const view = redeemShare(consent.token);
    expect(Object.keys(view.snapshot)).toEqual(['riskLevel']);
  });

  test('views are capped and then refused', () => {
    const consent = grantConsent({ selectedFields: ['symptoms'], payload });
    for (let i = 0; i < consent.maxViews; i += 1) redeemShare(consent.token);
    expect(() => redeemShare(consent.token)).toThrow(HttpError);
    try {
      redeemShare(consent.token);
    } catch (error) {
      expect(error.status).toBe(403);
    }
  });

  test('revocation deletes the snapshot immediately', () => {
    const consent = grantConsent({ selectedFields: ['symptoms', 'transcript'], payload });
    revokeConsent(consent.id);
    try {
      redeemShare(consent.token);
      throw new Error('should have thrown');
    } catch (error) {
      expect(error.status).toBe(403);
      expect(error.message).toMatch(/revoked/i);
    }
  });

  test('unknown tokens are rejected with 404', () => {
    expect(() => redeemShare('JSC-NOPE-NOPE')).toThrow(HttpError);
  });
});
