import request from 'supertest';
import { createApp } from '../server/app.js';

const app = createApp();

describe('API surface', () => {
  test('health reports all subsystem checks', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.checks).toMatchObject({
      storage: true,
      triageEngine: true,
      careDirectory: true,
      auditChain: true
    });
  });

  test('triage rejects an empty body with a validation envelope', async () => {
    const res = await request(app).post('/api/triage').send({});
    expect(res.status).toBe(400);
    expect(res.body.error).toMatchObject({ status: 400 });
    expect(Array.isArray(res.body.error.details)).toBe(true);
  });

  test('triage classifies a cardiac message as emergency', async () => {
    const res = await request(app)
      .post('/api/triage')
      .send({ text: 'mere chest mein bahut dard hai aur saans lene mein problem hai' });
    expect(res.status).toBe(200);
    expect(res.body.level).toBe('emergency');
    expect(res.body.flagsDetail.length).toBeGreaterThan(0);
  });

  test('chat keeps a session and never downgrades risk', async () => {
    const first = await request(app)
      .post('/api/chat')
      .send({ text: 'chest pain', language: 'en' });
    expect(first.status).toBe(200);
    const sessionId = first.body.sessionId;
    expect(sessionId).toBeTruthy();
    expect(first.body.triage.level).toBe('emergency');

    const second = await request(app)
      .post('/api/chat')
      .send({ sessionId, text: 'actually I feel fine now', language: 'en' });
    expect(second.body.triage.level).toBe('emergency');
  });

  test('care options are ranked and capability-matched', async () => {
    const res = await request(app).get('/api/care-options').query({ level: 'emergency', limit: 3 });
    expect(res.status).toBe(200);
    expect(res.body.results.length).toBeLessThanOrEqual(3);
    expect(res.body.results[0]).toHaveProperty('distance');
    expect(res.body.isDemoData).toBe(true);
  });

  test('emergency contacts localise', async () => {
    const res = await request(app).get('/api/emergency-contacts').query({ language: 'hi' });
    expect(res.status).toBe(200);
    expect(res.body.contacts.length).toBeGreaterThan(0);
  });

  test('redact masks secrets', async () => {
    const res = await request(app).post('/api/redact').send({ text: 'OTP 482913 and PIN 4321' });
    expect(res.status).toBe(200);
    expect(res.body.redactedText).not.toContain('482913');
  });

  test('consent -> share -> revoke lifecycle over HTTP', async () => {
    const granted = await request(app)
      .post('/api/consent')
      .send({ selectedFields: ['symptoms', 'riskLevel'], recipient: 'caregiver', payload: { symptoms: ['Chest pain'], riskLevel: 'emergency', transcript: ['secret'] } });
    expect(granted.status).toBe(201);
    const { token, id } = granted.body.consent;

    const shared = await request(app).get(`/api/share/${token}`);
    expect(shared.status).toBe(200);
    expect(shared.body.snapshot).toEqual({ symptoms: ['Chest pain'], riskLevel: 'emergency' });

    const revoked = await request(app).post(`/api/consent/${id}/revoke`).send({});
    expect(revoked.status).toBe(200);

    const after = await request(app).get(`/api/share/${token}`);
    expect(after.status).toBe(403);
  });

  test('audit chain verifies over HTTP', async () => {
    const res = await request(app).get('/api/audit/verify');
    expect(res.status).toBe(200);
    expect(res.body.valid).toBe(true);
  });

  test('unknown routes return the JSON 404 envelope', async () => {
    const res = await request(app).get('/api/does-not-exist');
    expect(res.status).toBe(404);
    expect(res.body.error.path).toBe('/api/does-not-exist');
  });

  test('malformed JSON returns 400, not 500', async () => {
    const res = await request(app)
      .post('/api/triage')
      .set('Content-Type', 'application/json')
      .send('{not json');
    expect(res.status).toBe(400);
  });

  test('security headers are present', async () => {
    const res = await request(app).get('/api/health');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-frame-options']).toBe('DENY');
    expect(res.headers['content-security-policy']).toContain("default-src 'none'");
  });
});
