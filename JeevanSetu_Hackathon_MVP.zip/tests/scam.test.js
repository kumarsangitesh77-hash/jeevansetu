import { detectScam, redactSecrets } from '../server/services/scam.js';

describe('scam detection', () => {
  const message = 'Hospital: your admission is cancelled. Pay Rs 5000 now to https://bit.ly/pay-fees and share OTP 482913 or bed will go.';

  test('a payment-pressure hospital message is likely scam', () => {
    const result = detectScam(message);
    expect(result.verdict).toBe('likely_scam');
    expect(result.severity).toBe('high');
    expect(result.confidence).toBeGreaterThanOrEqual(55);
  });

  test('structural findings expose the shortener and the amount', () => {
    const result = detectScam(message);
    expect(result.structural.shortenedUrls).toContain('bit.ly/pay-fees');
    expect(result.structural.amounts.join(' ')).toContain('5000');
  });

  test('Hinglish OTP demand is detected', () => {
    const result = detectScam('apka OTP batayein warna account band ho jayega');
    expect(result.isSuspicious).toBe(true);
  });

  test('a benign appointment reminder is low risk', () => {
    const result = detectScam('Your appointment is confirmed for Monday 10 am at the OPD counter.');
    expect(result.verdict).toBe('low_risk');
    expect(result.confidence).toBeLessThan(22);
  });
});

describe('secret redaction', () => {
  test('OTP, PIN, card and phone are masked', () => {
    const out = redactSecrets('My OTP is 482913 and UPI PIN 4321, card 4111 1111 1111 1111, call 9876543210');
    expect(out).toContain('OTP [REDACTED]');
    expect(out).toContain('PIN [REDACTED]');
    expect(out).toContain('[CARD-NUMBER]');
    expect(out).toContain('[PHONE]');
    expect(out).not.toContain('482913');
    expect(out).not.toContain('4321');
  });

  test('Hindi OTP phrasing is masked', () => {
    expect(redactSecrets('ओटीपी 123456 बताएं')).not.toContain('123456');
  });

  test('unrelated numbers survive', () => {
    expect(redactSecrets('fever 103 since 2 days')).toContain('103');
  });
});
