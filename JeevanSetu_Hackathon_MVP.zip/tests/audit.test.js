import fs from 'node:fs';
import path from 'node:path';
import { appendEvent, listEvents, verifyChain } from '../server/services/audit.js';
import config from '../server/config.js';

const auditFile = path.join(config.storage.dir, config.storage.auditFile);

describe('hash-chained audit log', () => {
  test('events are appended with increasing sequence numbers', () => {
    const before = listEvents({ limit: 1 }).events[0]?.seq ?? -1;
    appendEvent({ action: 'TRIAGE_ASSESSED', actorRole: 'patient', status: 'allowed', detail: { t: 1 } });
    appendEvent({ action: 'TRIAGE_ASSESSED', actorRole: 'patient', status: 'allowed', detail: { t: 2 } });
    const [second, first] = listEvents({ limit: 2 }).events;
    expect(first.seq).toBeGreaterThan(before);
    expect(second.seq).toBe(first.seq + 1);
  });

  test('the chain verifies intact', () => {
    const result = verifyChain();
    expect(result.valid).toBe(true);
    expect(result.algorithm).toBe('sha256');
    expect(result.recordCount).toBeGreaterThan(0);
  });

  test('each record links to the previous hash', () => {
    const lines = fs.readFileSync(auditFile, 'utf8').trim().split('\n').map(JSON.parse);
    for (let i = 1; i < lines.length; i += 1) {
      expect(lines[i].prevHash).toBe(lines[i - 1].hash);
    }
    expect(lines[0].prevHash).toBe('0'.repeat(64));
  });

  test('tampering with a record breaks verification', () => {
    const original = fs.readFileSync(auditFile, 'utf8');
    try {
      const lines = original.trim().split('\n');
      const target = Math.max(0, lines.length - 2);
      const record = JSON.parse(lines[target]);
      record.detail = { tampered: true };
      lines[target] = JSON.stringify(record);
      fs.writeFileSync(auditFile, `${lines.join('\n')}\n`);

      const result = verifyChain();
      expect(result.valid).toBe(false);
      expect(result.brokenAt).toBe(target);
    } finally {
      fs.writeFileSync(auditFile, original);
      verifyChain();
    }
  });
});
